onload = function() {
  let cont = 0;
  document.getElementById('btn').onclick = function() {
    cont ++;
    document.getElementById('value').innerHTML = cont;
  }
  document.getElementById('btn1').onclick = function() {
    cont --;
    document.getElementById('value').innerHTML = cont;
  }
}